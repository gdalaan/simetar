from os import sep
from flask import Flask, render_template, url_for,  request, send_file
import pandas as pd

app = Flask(__name__)
kode = []
@app.route('/', methods=['GET', 'POST'])
def main():
    return render_template('index.html')

@app.route('/data', methods=['GET', 'POST'])
def data():
    if request.method == 'POST':
        file = request.form['upload-file']
        df = pd.read_csv(file, names=['name'])
        for key in df['name']:
            if len(key.split()) == 9:
                kode.append(key)
    return render_template('data.html', data=kode)

@app.route('/download')
def download():
   return send_file('sample.csv', as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True)
